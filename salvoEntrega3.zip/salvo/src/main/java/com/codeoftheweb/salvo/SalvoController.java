package com.codeoftheweb.salvo;

import com.codeoftheweb.salvo.game.Game;
import com.codeoftheweb.salvo.game.GameRepository;
import com.codeoftheweb.salvo.gamePlayer.GamePlayer;
import com.codeoftheweb.salvo.gamePlayer.GamePlayerRepository;
import com.codeoftheweb.salvo.player.Player;
import com.codeoftheweb.salvo.player.PlayerRepository;
import com.codeoftheweb.salvo.ship.Ship;
import com.codeoftheweb.salvo.ship.ShipRepository;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

@RestController
@RequestMapping("/api")
public class SalvoController {

    @Autowired
    GameRepository gameRepository;

    @Autowired
    GamePlayerRepository gamePlayerRepository;

    @Autowired
    PlayerRepository playerRepository;

    @Autowired
    ShipRepository shipRepository;

    @RequestMapping("/game_view/{gamePlayerId}")
    public Map < String,Object> getGame(@PathVariable Long gamePlayerId){
        GamePlayer gamePlayer = gamePlayerRepository.findById(gamePlayerId).get();
        return makeGameViewDTO(gamePlayer);
    }


    @RequestMapping("/players")
    public  List<Map<String,Object>> getPlayerAll(){
        return playerRepository.findAll()
                .stream()
                .map(player -> makePlayerDTO(player))
                .collect(Collectors.toList());
    }

    @RequestMapping("/games")
    public List<Map<String,Object>> getGameAll(){
       return gameRepository.findAll()
               .stream()
               .map(game -> makeGameDTO(game))
               .collect(Collectors.toList());

    }
    private Map<String,Object> makeGameDTO(Game game){
            Map<String,Object> dto = new LinkedHashMap<>();
            dto.put("id",game.getId());
            dto.put("created",game.getCreationDate());
            dto.put("gamePlayers",game.getGamePlayers()
                                    .stream()
                                    .map(gamePlayer -> makeGamePlayerDTO(gamePlayer))
                                    .collect(Collectors.toList()));
        return dto;

    }
    private Map<String, Object> makeGamePlayerDTO(GamePlayer gamePlayer) {
            Map<String,Object> dto = new LinkedHashMap<>();
            dto.put("id",gamePlayer.getId());
            dto.put("player", makePlayerDTO (gamePlayer.getPlayer()));

          return dto;
    }
    private Map<String,Object> makePlayerDTO(Player player){
            Map<String,Object> dto = new LinkedHashMap<>();
            dto.put("id",player.getId());
            dto.put("email",player.getEmail());
            dto.put("name",player.getName());

           return dto;
    }
    private Map<String,Object> makeShipDTO(Ship ship){
            Map<String,Object> dto = new LinkedHashMap<>();
            dto.put("id",ship.getId());
            dto.put("type",ship.getType());
            dto.put("locations",ship.getLocations());

            return dto;

    }
    private Map<String,Object> makeGameViewDTO (GamePlayer gamePlayer) {
        Map<String,Object> dto = new LinkedHashMap<>();
        dto.put("id",gamePlayer.getGame().getId());
        dto.put("created",gamePlayer.getGame().getCreationDate());
        dto.put("gamePlayers", gamePlayer.getGame().getGamePlayers()
                .stream()
                .map(gp -> makeGamePlayerDTO(gp))
                .collect(Collectors.toList()));
        dto.put("ships",gamePlayer
                .getShip()
                .stream()
                .map(ship -> makeShipDTO(ship))
                .collect(Collectors.toList()));



        return dto;

    }





}
